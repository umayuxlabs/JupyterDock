
#root
c.ServerApp.password = 'sha256:91b4c5da59a7:e91ee7c51c707f18767aa4b5f900478b4111a0dd6529f216a38693cda1a61ad0'
c.ServerApp.password_required = True
